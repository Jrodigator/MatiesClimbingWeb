--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mcc;
--
-- Name: mcc; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE mcc WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_ZA.UTF-8';


\connect mcc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member (
    name character varying,
    surname character varying,
    username character varying,
    password character varying,
    email character varying,
    phone_number character varying,
    admin boolean,
    membership integer,
    active boolean,
    latest_payment integer,
    student_number character varying,
    id_number character varying,
    foreign_student character varying,
    gender character varying,
    member_id integer NOT NULL,
    membership_type integer,
    start_date date,
    end_date date
);


--
-- Name: member_member_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_member_id_seq OWNED BY public.member.member_id;


--
-- Name: membership_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_history (
    history_id integer NOT NULL,
    member_id integer NOT NULL,
    membership_type integer NOT NULL,
    start_date date,
    end_date date,
    payment integer
);


--
-- Name: membership_history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_history_history_id_seq OWNED BY public.membership_history.history_id;


--
-- Name: membership_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_type (
    membership_type_id integer NOT NULL,
    member_type character varying,
    price real,
    duration integer
);


--
-- Name: membership_type_membership_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_type_membership_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_type_membership_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_type_membership_type_id_seq OWNED BY public.membership_type.membership_type_id;


--
-- Name: payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment (
    pop_id integer NOT NULL,
    filepath character varying,
    upload_date date,
    filename character varying
);


--
-- Name: payment_pop_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_pop_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_pop_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_pop_id_seq OWNED BY public.payment.pop_id;


--
-- Name: member member_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member ALTER COLUMN member_id SET DEFAULT nextval('public.member_member_id_seq'::regclass);


--
-- Name: membership_history history_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_history ALTER COLUMN history_id SET DEFAULT nextval('public.membership_history_history_id_seq'::regclass);


--
-- Name: membership_type membership_type_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_type ALTER COLUMN membership_type_id SET DEFAULT nextval('public.membership_type_membership_type_id_seq'::regclass);


--
-- Name: payment pop_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment ALTER COLUMN pop_id SET DEFAULT nextval('public.payment_pop_id_seq'::regclass);


--
-- Data for Name: member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member (name, surname, username, password, email, phone_number, admin, membership, active, latest_payment, student_number, id_number, foreign_student, gender, member_id, membership_type, start_date, end_date) FROM stdin;
\.
COPY public.member (name, surname, username, password, email, phone_number, admin, membership, active, latest_payment, student_number, id_number, foreign_student, gender, member_id, membership_type, start_date, end_date) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: membership_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_history (history_id, member_id, membership_type, start_date, end_date, payment) FROM stdin;
\.
COPY public.membership_history (history_id, member_id, membership_type, start_date, end_date, payment) FROM '$$PATH$$/3379.dat';

--
-- Data for Name: membership_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_type (membership_type_id, member_type, price, duration) FROM stdin;
\.
COPY public.membership_type (membership_type_id, member_type, price, duration) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment (pop_id, filepath, upload_date, filename) FROM stdin;
\.
COPY public.payment (pop_id, filepath, upload_date, filename) FROM '$$PATH$$/3383.dat';

--
-- Name: member_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_member_id_seq', 23, true);


--
-- Name: membership_history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_history_history_id_seq', 1, false);


--
-- Name: membership_type_membership_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_type_membership_type_id_seq', 4, true);


--
-- Name: payment_pop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_pop_id_seq', 6, true);


--
-- Name: member member_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pk PRIMARY KEY (member_id);


--
-- Name: membership_history membership_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_history
    ADD CONSTRAINT membership_history_pk PRIMARY KEY (history_id);


--
-- Name: membership_type membership_type_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_type
    ADD CONSTRAINT membership_type_pk PRIMARY KEY (membership_type_id);


--
-- Name: payment payment_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pk PRIMARY KEY (pop_id);


--
-- Name: member member_payment_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_payment_fk FOREIGN KEY (latest_payment) REFERENCES public.payment(pop_id);


--
-- Name: membership_history membership_history_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_history
    ADD CONSTRAINT membership_history_fk FOREIGN KEY (member_id) REFERENCES public.member(member_id);


--
-- Name: membership_history membership_history_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_history
    ADD CONSTRAINT membership_history_fk_1 FOREIGN KEY (membership_type) REFERENCES public.membership_type(membership_type_id);


--
-- Name: membership_history membership_history_payment_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_history
    ADD CONSTRAINT membership_history_payment_fk FOREIGN KEY (payment) REFERENCES public.payment(pop_id);


--
-- Name: member membership_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT membership_type_fk FOREIGN KEY (membership_type) REFERENCES public.membership_type(membership_type_id);


--
-- PostgreSQL database dump complete
--

